import { NextRequest, NextResponse } from "next/server";
import { generateObject } from "ai";
import { createGoogleGenerativeAI } from "@ai-sdk/google";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { resolvePortfolioId } from "@/lib/portfolio";
import { getQuote } from "@/lib/market";
import type { Exchange } from "@/lib/india";

const DecisionSchema = z.object({
  date: z.string(),
  marketContext: z.string(),
  todayDecisions: z.array(z.object({
    symbol: z.string(),
    action: z.enum(["BUY", "ACCUMULATE", "HOLD", "REDUCE", "SELL", "WATCH"]),
    reason: z.string(),
    urgency: z.enum(["URGENT", "HIGH", "MEDIUM", "LOW"]),
    priceLevel: z.string(),
  })),
  highConviction: z.array(z.object({
    symbol: z.string(),
    direction: z.enum(["LONG", "EXIT"]),
    why: z.string(),
    confidence: z.number().min(0).max(100),
    timeframe: z.string(),
    catalyst: z.string(),
  })),
  alerts: z.object({
    nearStopLoss: z.array(z.object({
      symbol: z.string(),
      currentPrice: z.number(),
      stopLoss: z.number(),
      distancePct: z.number(),
      action: z.string(),
    })),
    nearTarget: z.array(z.object({
      symbol: z.string(),
      currentPrice: z.number(),
      target: z.number(),
      distancePct: z.number(),
      action: z.string(),
    })),
  }),
  portfolioStrengths: z.array(z.string()),
  portfolioWeaknesses: z.array(z.string()),
  weeklyPlan: z.string(),
  disclaimer: z.string(),
});

export type DecisionData = z.infer<typeof DecisionSchema>;

type EnrichedE = {
  symbol: string;
  name: string;
  shares: number;
  avgCost: number;
  sector: string | null;
  currentPrice: number;
  stopLoss: number;
  target: number;
  gl: number;
  distFromSL: number;
  distFromTarget: number;
  changePercent: number;
};

export async function GET(req: NextRequest) {
  const portfolioId = await resolvePortfolioId(req.nextUrl.searchParams.get("portfolioId"));
  const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY;
  const holdings = await prisma.holding.findMany({ where: { portfolioId } });

  if (holdings.length === 0) {
    return NextResponse.json({ error: "No holdings found." }, { status: 400 });
  }

  const quoteResults = await Promise.allSettled(
    holdings.map((h) => getQuote(h.symbol, (h.exchange as Exchange) ?? "NSE"))
  );

  const enriched: EnrichedE[] = holdings.map((h, i) => {
    const q = quoteResults[i].status === "fulfilled"
      ? (quoteResults[i] as PromiseFulfilledResult<Awaited<ReturnType<typeof getQuote>>>).value
      : null;
    const price = q?.price ?? h.avgCost;
    const stopLoss = h.avgCost * 0.88;
    const target = h.avgCost * 1.25;
    const gl = ((price - h.avgCost) / h.avgCost) * 100;
    const distFromSL = ((price - stopLoss) / price) * 100;
    const distFromTarget = ((target - price) / price) * 100;
    return { symbol: h.symbol, name: h.name, shares: h.shares, avgCost: h.avgCost, sector: h.sector, currentPrice: price, stopLoss, target, gl, distFromSL, distFromTarget, changePercent: q?.changePercent ?? 0 };
  });

  const totalValue = enriched.reduce((s, h) => s + h.currentPrice * h.shares, 0);
  const totalCost = enriched.reduce((s, h) => s + h.avgCost * h.shares, 0);
  const portfolioGL = ((totalValue - totalCost) / totalCost) * 100;
  const dayChange = enriched.reduce((s, h) => s + h.changePercent * h.currentPrice * h.shares, 0) / (totalValue || 1);

  if (!apiKey || apiKey === "your-gemini-api-key-here") {
    return NextResponse.json(getMockDecisions(enriched, portfolioGL, dayChange));
  }

  const google = createGoogleGenerativeAI({ apiKey });
  const today = new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

  const prompt = `You are RAIOS, an expert Indian equity trader and portfolio manager. Today is ${today}.

Generate today's actionable decision dashboard for this portfolio:

PORTFOLIO: ₹${totalValue.toFixed(0)} total, ${portfolioGL.toFixed(2)}% G/L, today ${dayChange.toFixed(2)}%

HOLDINGS (symbol, current price, today%, G/L%, avg cost):
${enriched.map(h => `${h.symbol}: ₹${h.currentPrice.toFixed(0)} (${h.changePercent > 0 ? "+" : ""}${h.changePercent.toFixed(2)}% today), avg ₹${h.avgCost.toFixed(0)}, G/L: ${h.gl > 0 ? "+" : ""}${h.gl.toFixed(1)}%`).join("\n")}

Generate:
1. For EACH holding: specific action (BUY/ACCUMULATE/HOLD/REDUCE/SELL/WATCH), reason, urgency, and price level
2. Top 2-3 high conviction plays (LONG or EXIT), confidence %, timeframe, catalyst
3. Which holdings are near their stop-loss (within 8% of -12% from avg cost) or near target (+25% from avg cost)
4. 3-4 portfolio strengths and 3-4 weaknesses
5. Weekly plan (2-3 sentences)`;

  try {
    const { object } = await generateObject({
      model: google("gemini-2.5-flash"),
      schema: DecisionSchema,
      prompt,
    });
    return NextResponse.json(object);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("[ai/decision] Gemini error:", msg);
    const isQuota = msg.includes("quota") || msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED");
    const isAuth  = msg.includes("API_KEY_INVALID") || msg.includes("401") || msg.includes("UNAUTHENTICATED");
    const label   = isQuota ? "Gemini free-tier quota exceeded (20 req/day). Showing rule-based decisions — quota resets at midnight Pacific time."
                  : isAuth  ? `Gemini API key rejected: ${msg}`
                  :           `Gemini error: ${msg}`;
    return NextResponse.json(
      { ...getMockDecisions(enriched, portfolioGL, dayChange), aiError: label },
      { status: 200 }
    );
  }
}

function getMockDecisions(holdings: EnrichedE[], portfolioGL: number, dayChange: number): DecisionData {
  const today = new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
  const nearSL = holdings.filter(h => h.distFromSL < 8 && h.gl < 0);
  const nearTarget = holdings.filter(h => h.distFromTarget < 10 && h.gl > 0);
  const topGainer = [...holdings].sort((a, b) => b.gl - a.gl)[0];
  const topLoser = [...holdings].sort((a, b) => a.gl - b.gl)[0];
  const sectorSet = new Set(holdings.map(h => h.sector ?? "Other"));

  return {
    date: today,
    marketContext: `Portfolio ${dayChange > 0 ? "up" : "down"} ${Math.abs(dayChange).toFixed(2)}% today. ${dayChange > 1 ? "Strong session — monitor for end-of-day profit booking." : dayChange < -1 ? "Weak day — support levels are critical. Watch for bounce." : "Mixed market. Wait for directional clarity before acting."}`,
    todayDecisions: holdings.slice(0, 8).map(h => ({
      symbol: h.symbol,
      action: (h.gl > 30 ? "REDUCE" : h.gl < -15 ? "WATCH" : h.changePercent < -2.5 ? "ACCUMULATE" : "HOLD") as "REDUCE" | "WATCH" | "ACCUMULATE" | "HOLD" | "BUY" | "SELL",
      reason: h.gl > 30
        ? `Up ${h.gl.toFixed(0)}% — consider booking 20-30% of position for partial profit realization.`
        : h.gl < -15
        ? `Down ${Math.abs(h.gl).toFixed(0)}% — monitor stop-loss at ₹${h.stopLoss.toFixed(0)}. Review investment thesis.`
        : h.changePercent < -2.5
        ? `Dip of ${Math.abs(h.changePercent).toFixed(1)}% today — potential accumulation at support.`
        : `No urgent action. Hold and track earnings/sector news.`,
      urgency: (nearSL.some(s => s.symbol === h.symbol) ? "URGENT" : h.gl < -20 ? "HIGH" : h.gl > 30 ? "MEDIUM" : "LOW") as "URGENT" | "HIGH" | "MEDIUM" | "LOW",
      priceLevel: `₹${h.currentPrice.toFixed(0)}`,
    })),
    highConviction: [
      ...(topGainer && topGainer.gl > 5 ? [{
        symbol: topGainer.symbol,
        direction: "LONG" as const,
        why: `Best performer at +${topGainer.gl.toFixed(1)}%. Strong momentum with intact uptrend.`,
        confidence: 72,
        timeframe: "3-6 months",
        catalyst: "Earnings growth momentum and sector tailwinds",
      }] : []),
      ...(topLoser && topLoser.gl < -10 ? [{
        symbol: topLoser.symbol,
        direction: "EXIT" as const,
        why: `Weakest performer at ${topLoser.gl.toFixed(1)}%. Underperforming sector peers.`,
        confidence: 65,
        timeframe: "Immediate — within this week",
        catalyst: "Stop-loss discipline; redeploy capital to stronger names",
      }] : []),
    ],
    alerts: {
      nearStopLoss: nearSL.map(h => ({
        symbol: h.symbol,
        currentPrice: h.currentPrice,
        stopLoss: h.stopLoss,
        distancePct: h.distFromSL,
        action: `Only ${h.distFromSL.toFixed(1)}% above stop-loss. Place stop order at ₹${h.stopLoss.toFixed(0)} or review thesis now.`,
      })),
      nearTarget: nearTarget.map(h => ({
        symbol: h.symbol,
        currentPrice: h.currentPrice,
        target: h.target,
        distancePct: h.distFromTarget,
        action: `${h.distFromTarget.toFixed(1)}% from target ₹${h.target.toFixed(0)}. Consider booking 20-30% on approach.`,
      })),
    },
    portfolioStrengths: [
      portfolioGL > 0 ? `Portfolio is profitable overall (+${portfolioGL.toFixed(1)}% unrealized gain)` : "Portfolio positioned for recovery with quality holdings",
      `${sectorSet.size} sector${sectorSet.size > 1 ? "s" : ""} represented — ${sectorSet.size >= 4 ? "good" : "basic"} diversification`,
      `${holdings.filter(h => h.gl > 0).length} of ${holdings.length} positions in profit`,
      "Active monitoring with defined stop-loss and target levels",
    ].slice(0, 4),
    portfolioWeaknesses: [
      ...(nearSL.length > 0 ? [`${nearSL.length} holding${nearSL.length > 1 ? "s" : ""} (${nearSL.map(h => h.symbol).join(", ")}) near stop-loss — elevated exit risk`] : []),
      ...(sectorSet.size < 4 ? ["Sector concentration below 4 sectors — limited diversification"] : []),
      ...(holdings.some(h => h.gl < -20) ? ["Significant drawdown in some positions — capital at risk"] : []),
      "No automated stop-loss orders in place — requires daily monitoring",
    ].slice(0, 4),
    weeklyPlan: `${nearSL.length > 0 ? `Immediate priority: review ${nearSL.map(h => h.symbol).join(", ")} approaching stop-loss.` : "Maintain current positions."} ${nearTarget.length > 0 ? `Prepare partial exit plan for ${nearTarget.map(h => h.symbol).join(", ")} near targets.` : ""} Review sector rotation and consider deploying cash in quality large-caps on dips.`,
    disclaimer: "Showing rule-based estimates using your portfolio data. Not a substitute for professional financial advice.",
  };
}
