"use client";

import { useState, useEffect, useRef, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatCurrency, formatPercent } from "@/lib/utils";
import type { AIAnalysisResult, TechnicalIndicators, MarketQuote, ChatMessage } from "@/types";
import {
  Brain, Search, RefreshCw, TrendingUp, TrendingDown,
  Shield, Target, AlertTriangle, CheckCircle, XCircle,
  MessageSquare, Send, Loader2, Zap, Star, BarChart2,
  Calendar, Sparkles, TrendingDown as ThumbDown, ArrowRight,
  Briefcase, Crosshair,
} from "lucide-react";
import type { DailyBrief } from "@/app/api/ai/brief/route";
import type { OpportunitiesData } from "@/app/api/ai/opportunities/route";
import type { PortfolioManagerData } from "@/app/api/ai/portfolio-manager/route";
import type { DecisionData } from "@/app/api/ai/decision/route";
import type { ForecastData } from "@/app/api/ai/forecast/route";
import { resolveSearchSymbol } from "@/lib/india";
import { usePortfolio } from "@/contexts/portfolio-context";

interface FullAnalysis extends AIAnalysisResult {
  indicators?: TechnicalIndicators;
  quote?: MarketQuote;
  cached?: boolean;
}

function ScoreMeter({ score }: { score: number }) {
  const color = score >= 7 ? "#22c55e" : score >= 4 ? "#eab308" : "#ef4444";
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const progress = (score / 10) * circumference;
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-32 h-32">
        <svg className="w-32 h-32 -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r={radius} fill="none" stroke="hsl(var(--border))" strokeWidth="8" />
          <circle cx="60" cy="60" r={radius} fill="none" stroke={color} strokeWidth="8"
            strokeDasharray={`${progress} ${circumference}`} strokeLinecap="round" />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-bold" style={{ color }}>{score.toFixed(1)}</span>
          <span className="text-xs text-muted-foreground">/10</span>
        </div>
      </div>
      <p className="text-sm font-medium" style={{ color }}>
        {score >= 7 ? "Strong Buy" : score >= 6 ? "Buy" : score >= 4 ? "Hold" : score >= 2 ? "Sell" : "Strong Sell"}
      </p>
    </div>
  );
}

// ──────────────────────────── DAILY BRIEF ────────────────────────────
function BriefTab({ portfolioId }: { portfolioId: string }) {
  const [brief, setBrief] = useState<DailyBrief | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchBrief = async () => {
    setLoading(true);
    setError("");
    try {
      const url = portfolioId ? `/api/ai/brief?portfolioId=${portfolioId}` : "/api/ai/brief";
      const res = await fetch(url);
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed to generate brief");
      }
      setBrief(await res.json());
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Failed");
    }
    setLoading(false);
  };

  useEffect(() => { fetchBrief(); }, [portfolioId]);

  const actionColor = (action: string) => {
    if (["BUY", "ACCUMULATE"].includes(action)) return "text-green-400 bg-green-400/10 border-green-400/30";
    if (["SELL", "REDUCE"].includes(action)) return "text-red-400 bg-red-400/10 border-red-400/30";
    if (action === "WATCH") return "text-blue-400 bg-blue-400/10 border-blue-400/30";
    return "text-yellow-400 bg-yellow-400/10 border-yellow-400/30";
  };

  const sentimentColor = brief?.marketSentiment.overall === "BULLISH" ? "text-green-400" : brief?.marketSentiment.overall === "BEARISH" ? "text-red-400" : "text-yellow-400";

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2"><Calendar className="h-5 w-5 text-primary" /> Daily AI Investment Brief</h2>
          {brief?.date && <p className="text-xs text-muted-foreground">{brief.date}</p>}
        </div>
        <Button variant="outline" size="sm" onClick={fetchBrief} disabled={loading}>
          <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? "animate-spin" : ""}`} />
          Regenerate
        </Button>
      </div>

      {error && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-destructive text-sm">{error}</div>}

      {loading && (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Brain className="h-12 w-12 text-primary animate-pulse" />
          <p className="text-muted-foreground">AI is analyzing your portfolio…</p>
        </div>
      )}

      {brief && !loading && (
        <>
          {/* Health + Sentiment */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="rounded-lg border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground mb-2">Portfolio Health</p>
              <div className="flex items-center gap-3">
                <div className="relative h-16 w-16">
                  <svg className="h-16 w-16 -rotate-90" viewBox="0 0 64 64">
                    <circle cx="32" cy="32" r="26" fill="none" stroke="hsl(var(--border))" strokeWidth="6" />
                    <circle cx="32" cy="32" r="26" fill="none"
                      stroke={brief.portfolioHealth.score >= 70 ? "#22c55e" : brief.portfolioHealth.score >= 40 ? "#eab308" : "#ef4444"}
                      strokeWidth="6"
                      strokeDasharray={`${(brief.portfolioHealth.score / 100) * 163.4} 163.4`}
                      strokeLinecap="round" />
                  </svg>
                  <span className="absolute inset-0 flex items-center justify-center text-sm font-bold">{brief.portfolioHealth.score}</span>
                </div>
                <div>
                  <p className="text-2xl font-bold">{brief.portfolioHealth.grade}</p>
                  <p className="text-xs text-muted-foreground">Portfolio Grade</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{brief.portfolioHealth.summary}</p>
            </div>

            <div className="rounded-lg border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground mb-2">Market Sentiment</p>
              <p className={`text-2xl font-bold ${sentimentColor}`}>{brief.marketSentiment.overall}</p>
              <p className="text-xs mt-2 leading-relaxed">{brief.marketSentiment.india}</p>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{brief.marketSentiment.global}</p>
            </div>

            <div className="rounded-lg border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground mb-2">Key Theme This Week</p>
              <p className="text-sm leading-relaxed">{brief.keyTheme}</p>
              <div className="mt-3 pt-3 border-t border-border">
                <p className="text-xs text-muted-foreground">Sector Rotation</p>
                <p className="text-xs mt-1 leading-relaxed">{brief.sectorRotation}</p>
              </div>
            </div>
          </div>

          {/* Today's Actions */}
          {brief.todayActions.length > 0 && (
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2"><Zap className="h-4 w-4 text-primary" /> Today&apos;s Actions</h3>
              <div className="grid gap-2">
                {brief.todayActions.map((a, i) => (
                  <div key={i} className={`flex items-start gap-3 rounded-lg border px-3 py-2.5 ${actionColor(a.action)}`}>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded font-mono border ${actionColor(a.action)}`}>{a.action}</span>
                    <div className="flex-1">
                      <span className="font-mono font-bold">{a.symbol}</span>
                      <p className="text-xs mt-0.5 opacity-80">{a.reason}</p>
                    </div>
                    <Badge variant="outline" className={`text-xs shrink-0 ${a.urgency === "HIGH" ? "border-red-500 text-red-400" : a.urgency === "MEDIUM" ? "border-yellow-500 text-yellow-400" : "border-border"}`}>
                      {a.urgency}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Top Opportunity + Highest Risk */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-lg border border-green-900/40 bg-green-900/10 p-4">
              <h3 className="font-semibold text-green-400 flex items-center gap-2 mb-3"><Star className="h-4 w-4" /> Top Opportunity</h3>
              <p className="font-mono font-bold text-lg">{brief.topOpportunity.symbol}</p>
              <p className="text-sm mt-1 leading-relaxed">{brief.topOpportunity.why}</p>
              <div className="grid grid-cols-3 gap-2 mt-3 text-xs">
                <div><p className="text-muted-foreground">Entry</p><p className="font-mono">{brief.topOpportunity.entryRange}</p></div>
                <div><p className="text-muted-foreground">Target</p><p className="font-mono text-green-400">{brief.topOpportunity.target}</p></div>
                <div><p className="text-muted-foreground">Risk</p><p className="font-mono text-xs opacity-70">{brief.topOpportunity.risk.slice(0, 20)}…</p></div>
              </div>
            </div>

            <div className="rounded-lg border border-red-900/40 bg-red-900/10 p-4">
              <h3 className="font-semibold text-red-400 flex items-center gap-2 mb-3"><AlertTriangle className="h-4 w-4" /> Highest Risk Holding</h3>
              <p className="font-mono font-bold text-lg">{brief.highestRisk.symbol}</p>
              <p className="text-sm mt-1 leading-relaxed">{brief.highestRisk.risk}</p>
              <div className="mt-3 pt-3 border-t border-red-900/30">
                <p className="text-xs text-muted-foreground">Recommended Action</p>
                <p className="text-xs mt-1">{brief.highestRisk.action}</p>
              </div>
            </div>
          </div>

          {/* Other insights */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="font-semibold mb-2 text-sm">Cash Deployment</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{brief.cashDeployment}</p>
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="font-semibold mb-2 text-sm">Rebalancing Insight</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{brief.rebalancingSuggestion}</p>
            </div>
          </div>

          <p className="text-xs text-muted-foreground text-center">{brief.disclaimer}</p>
        </>
      )}
    </div>
  );
}

// ──────────────────────────── OPPORTUNITIES ────────────────────────────
function OpportunitiesTab({ portfolioId }: { portfolioId: string }) {
  const [data, setData] = useState<OpportunitiesData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetch_ = async () => {
    setLoading(true);
    setError("");
    try {
      const url = portfolioId ? `/api/ai/opportunities?portfolioId=${portfolioId}` : "/api/ai/opportunities";
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed");
      setData(await res.json());
    } catch {
      setError("Failed to load opportunities. Check your connection.");
    }
    setLoading(false);
  };

  useEffect(() => { fetch_(); }, [portfolioId]);

  const convictionColor = (c: string) => c === "HIGH" ? "text-green-400 border-green-500/40 bg-green-500/10" : c === "MEDIUM" ? "text-yellow-400 border-yellow-500/40 bg-yellow-500/10" : "text-muted-foreground border-border bg-secondary/50";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2"><Sparkles className="h-5 w-5 text-primary" /> AI Opportunity Engine</h2>
          {data?.generatedAt && <p className="text-xs text-muted-foreground">{data.generatedAt}</p>}
        </div>
        <Button variant="outline" size="sm" onClick={fetch_} disabled={loading}>
          <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {error && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-destructive text-sm">{error}</div>}

      {loading && (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Sparkles className="h-12 w-12 text-primary animate-pulse" />
          <p className="text-muted-foreground">Scanning market for opportunities…</p>
        </div>
      )}

      {data && !loading && (
        <>
          {/* Top Buys */}
          <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2 text-green-400"><TrendingUp className="h-4 w-4" /> Top Buy Opportunities</h3>
            <div className="grid gap-3">
              {data.topBuys.map((s) => (
                <div key={s.symbol} className="rounded-lg border border-border bg-card p-4 flex gap-4">
                  <div className="flex-shrink-0 flex flex-col items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary font-bold text-lg">
                    {s.rank}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-primary text-lg">{s.symbol}</span>
                      <span className="text-sm text-muted-foreground">{s.name}</span>
                      <Badge variant="outline" className={`ml-auto text-xs ${convictionColor(s.conviction)}`}>{s.conviction} CONVICTION</Badge>
                    </div>
                    <p className="text-sm mt-1 leading-relaxed">{s.why}</p>
                    <div className="flex flex-wrap gap-4 mt-2 text-xs">
                      <span><span className="text-muted-foreground">Price:</span> <span className="font-mono">{s.price}</span></span>
                      <span><span className="text-muted-foreground">Target:</span> <span className="font-mono text-green-400">{s.target}</span></span>
                      <span><span className="text-muted-foreground">Upside:</span> <span className="font-mono text-green-400">{s.upside}</span></span>
                      <span><span className="text-muted-foreground">Timeframe:</span> <span className="font-mono">{s.timeframe}</span></span>
                    </div>
                    <p className="text-xs text-red-400/80 mt-1"><AlertTriangle className="inline h-3 w-3 mr-1" />Risk: {s.risk}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Swing Trades + Momentum + Gems in 3 cols */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Swing Trades */}
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2 text-blue-400 text-sm"><BarChart2 className="h-4 w-4" /> Swing Trades</h3>
              <div className="space-y-3">
                {data.swingTrades.map((s) => (
                  <div key={s.symbol} className="border-b border-border pb-3 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-primary">{s.symbol}</span>
                      <span className="text-xs text-muted-foreground">{s.duration}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">{s.name}</p>
                    <p className="text-xs mt-1 leading-relaxed">{s.why}</p>
                    <div className="text-xs mt-1.5 flex gap-3">
                      <span><span className="text-muted-foreground">Entry:</span> <span className="font-mono">{s.entry}</span></span>
                    </div>
                    <div className="text-xs flex gap-3">
                      <span className="text-green-400">Target: {s.target}</span>
                      <span className="text-red-400">SL: {s.stopLoss}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Momentum Leaders */}
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2 text-yellow-400 text-sm"><Zap className="h-4 w-4" /> Momentum Leaders</h3>
              <div className="space-y-3">
                {data.momentumLeaders.map((s) => (
                  <div key={s.symbol} className="border-b border-border pb-3 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-primary">{s.symbol}</span>
                      <span className="text-xs text-yellow-400 font-mono">{s.momentum}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{s.name}</p>
                    <p className="text-xs mt-1 leading-relaxed">{s.why}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Hidden Gems + Avoid */}
            <div className="space-y-4">
              <div className="rounded-lg border border-border bg-card p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2 text-purple-400 text-sm"><Star className="h-4 w-4" /> Hidden Gems</h3>
                <div className="space-y-3">
                  {data.hiddenGems.map((s) => (
                    <div key={s.symbol} className="border-b border-border pb-3 last:border-0 last:pb-0">
                      <span className="font-mono font-bold text-primary">{s.symbol}</span>
                      <p className="text-xs text-muted-foreground">{s.name}</p>
                      <p className="text-xs mt-1 leading-relaxed">{s.why}</p>
                      <p className="text-xs text-purple-400 mt-0.5">Catalyst: {s.catalyst}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-lg border border-red-900/40 bg-red-900/5 p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2 text-red-400 text-sm"><ThumbDown className="h-4 w-4" /> Avoid Now</h3>
                <div className="space-y-2">
                  {data.avoidList.map((s) => (
                    <div key={s.symbol}>
                      <span className="font-mono font-bold text-red-400">{s.symbol}</span>
                      <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{s.reason}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Market Outlook */}
          <div className="rounded-lg border border-border bg-card p-4">
            <h3 className="font-semibold mb-2 text-sm flex items-center gap-2"><ArrowRight className="h-4 w-4 text-primary" /> Market Outlook</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{data.marketOutlook}</p>
          </div>
        </>
      )}
    </div>
  );
}

// ──────────────────────────── CHAT ────────────────────────────
function ChatTab() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: "Namaste! I'm your AI Investment Advisor for the Indian market. Ask me anything:\n\n• \"Should I buy Reliance?\"\n• \"Where should I invest ₹5,00,000?\"\n• \"Review my portfolio\"\n• \"What are the top IT stocks on NSE?\"\n• \"How is RBI policy affecting banks?\"",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const QUICK_PROMPTS = [
    "Review my portfolio",
    "Best Nifty 50 stocks to buy now",
    "Where to invest ₹1,00,000?",
    "Top IT stocks on NSE",
    "How is inflation affecting markets?",
    "Explain SEBI regulations for retail investors",
  ];

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const sendMessage = async (text?: string) => {
    const msg = (text ?? input).trim();
    if (!msg || loading) return;
    setInput("");
    const userMsg: ChatMessage = { role: "user", content: msg, timestamp: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);
    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: msg }),
      });
      const data = await res.json();
      setMessages((prev) => [...prev, { role: "assistant", content: data.reply ?? data.error ?? "Sorry, I could not process that.", timestamp: new Date() }]);
    } catch {
      setMessages((prev) => [...prev, { role: "assistant", content: "Network error. Please try again.", timestamp: new Date() }]);
    }
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-220px)] min-h-[500px]">
      <div className="flex-1 overflow-y-auto space-y-4 p-4 rounded-lg border border-border bg-card">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[80%] rounded-lg px-4 py-3 text-sm whitespace-pre-wrap ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"}`}>
              {m.role === "assistant" && (
                <div className="flex items-center gap-1.5 mb-1.5">
                  <Brain className="h-3 w-3 text-primary" />
                  <span className="text-xs font-semibold text-primary">Gemini AI</span>
                </div>
              )}
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-secondary rounded-lg px-4 py-3 flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-3 w-3 animate-spin" /> Thinking…
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div className="flex gap-2 overflow-x-auto py-2">
        {QUICK_PROMPTS.map((p) => (
          <button key={p} onClick={() => sendMessage(p)} disabled={loading} className="text-xs px-3 py-1.5 rounded-full border border-border hover:bg-accent transition-colors whitespace-nowrap disabled:opacity-50">{p}</button>
        ))}
      </div>
      <div className="flex gap-2">
        <Input placeholder="Ask about Indian stocks, portfolio, market trends…" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()} disabled={loading} className="flex-1" />
        <Button onClick={() => sendMessage()} disabled={loading || !input.trim()} size="icon">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </div>
    </div>
  );
}

// ──────────────────────────── ANALYSIS ────────────────────────────
function AnalysisTab() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [symbol, setSymbol] = useState(searchParams.get("symbol") ?? "RELIANCE");
  const [inputVal, setInputVal] = useState(searchParams.get("symbol") ?? "RELIANCE");
  const [exchange, setExchange] = useState(searchParams.get("exchange") ?? "NSE");
  const [analysis, setAnalysis] = useState<FullAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const runAnalysis = async (sym: string, force = false) => {
    setLoading(true);
    setError("");
    try {
      const url = `/api/analysis/${sym}?exchange=${exchange}${force ? "&force=true" : ""}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Analysis failed");
      const data = await res.json();
      setAnalysis(data);
      router.replace(`/ai?symbol=${sym}&exchange=${exchange}`);
    } catch {
      setError(`Failed to analyze "${sym}". Check the symbol and try again.`);
    }
    setLoading(false);
  };

  useEffect(() => { runAnalysis(symbol); }, []);

  const handleSearch = () => {
    const s = resolveSearchSymbol(inputVal.trim());
    if (s) { setSymbol(s); setInputVal(s); runAnalysis(s); }
  };

  const signalColors: Record<string, { bg: string; text: string; border: string }> = {
    BUY: { bg: "#22c55e22", text: "#22c55e", border: "#22c55e55" },
    ACCUMULATE: { bg: "#22c55e22", text: "#22c55e", border: "#22c55e55" },
    HOLD: { bg: "#eab30822", text: "#eab308", border: "#eab30855" },
    REDUCE: { bg: "#f9731622", text: "#f97316", border: "#f9731655" },
    SELL: { bg: "#ef444422", text: "#ef4444", border: "#ef444455" },
  };

  return (
    <div className="space-y-6">
      <div className="flex gap-2 max-w-sm items-center">
        <Input placeholder="NSE symbol (RELIANCE, TCS…)" value={inputVal} onChange={(e) => setInputVal(e.target.value.toUpperCase())} onKeyDown={(e) => e.key === "Enter" && handleSearch()} className="font-mono" />
        <select value={exchange} onChange={(e) => setExchange(e.target.value)} className="h-9 rounded-md border border-input bg-background px-3 text-sm">
          <option value="NSE">NSE</option>
          <option value="BSE">BSE</option>
        </select>
        <Button onClick={handleSearch} disabled={loading}><Search className="h-4 w-4" /></Button>
      </div>

      {error && <p className="text-destructive text-sm">{error}</p>}

      {loading && (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Brain className="h-12 w-12 text-primary animate-pulse" />
          <p className="text-muted-foreground">Calculating indicators &amp; consulting AI…</p>
        </div>
      )}

      {analysis && !loading && (
        <>
          {analysis.quote && (
            <div className="flex items-center gap-4 rounded-lg border border-border bg-card p-4">
              <div>
                <h2 className="text-xl font-bold font-mono">{analysis.quote.symbol}</h2>
                <p className="text-sm text-muted-foreground">{analysis.quote.name}</p>
              </div>
              <div className="ml-4">
                <p className="text-xl font-mono font-bold">{formatCurrency(analysis.quote.price)}</p>
                <p className={`text-sm ${analysis.quote.changePercent >= 0 ? "gain" : "loss"}`}>
                  {analysis.quote.changePercent >= 0 ? <TrendingUp className="inline h-3 w-3 mr-1" /> : <TrendingDown className="inline h-3 w-3 mr-1" />}
                  {formatPercent(analysis.quote.changePercent)}
                </p>
              </div>
              {analysis.cached && <Badge variant="outline" className="ml-auto text-xs">Cached</Badge>}
              <Button variant="outline" size="sm" className="ml-auto" onClick={() => runAnalysis(symbol, true)}>
                <RefreshCw className="h-3 w-3 mr-1" /> Refresh
              </Button>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="rounded-lg border bg-card p-6 flex flex-col items-center gap-4" style={{ borderColor: signalColors[analysis.signal].border }}>
              <div className="rounded-full px-8 py-3 text-2xl font-bold tracking-wider" style={{ backgroundColor: signalColors[analysis.signal].bg, color: signalColors[analysis.signal].text }}>
                {analysis.signal}
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Confidence</p>
                <p className="text-2xl font-bold" style={{ color: signalColors[analysis.signal].text }}>{analysis.confidence}%</p>
              </div>
              <ScoreMeter score={analysis.investmentScore} />
            </div>

            <div className="rounded-lg border border-border bg-card p-6 space-y-4">
              <h3 className="font-semibold">Price Targets</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg bg-green-900/20 border border-green-900/30">
                  <div className="flex items-center gap-2"><Target className="h-4 w-4 text-green-400" /><span className="text-sm">Target Price</span></div>
                  <span className="font-mono font-bold text-green-400">{formatCurrency(analysis.targetPrice)}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-red-900/20 border border-red-900/30">
                  <div className="flex items-center gap-2"><Shield className="h-4 w-4 text-red-400" /><span className="text-sm">Stop Loss</span></div>
                  <span className="font-mono font-bold text-red-400">{formatCurrency(analysis.stopLoss)}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 border border-border">
                  <div className="flex items-center gap-2"><TrendingUp className="h-4 w-4 text-muted-foreground" /><span className="text-sm">Entry Zone</span></div>
                  <span className="font-mono text-sm font-medium">{analysis.entryZone}</span>
                </div>
                {analysis.quote && (
                  <div className="pt-2 text-xs text-muted-foreground text-center">
                    Upside: {formatPercent(((analysis.targetPrice - analysis.quote.price) / analysis.quote.price) * 100)} |
                    Risk: {formatPercent(((analysis.stopLoss - analysis.quote.price) / analysis.quote.price) * 100)}
                  </div>
                )}
              </div>
            </div>

            <div className="rounded-lg border border-border bg-card p-6 space-y-4">
              <h3 className="font-semibold">AI Summary</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{analysis.summary}</p>
              {analysis.indicators && (
                <div className="space-y-2 pt-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Key Metrics</p>
                  {[
                    { label: "RSI", value: analysis.indicators.rsi.toFixed(1) },
                    { label: "Trend", value: analysis.indicators.trend },
                    { label: "MACD", value: analysis.indicators.macdHistogram > 0 ? "Bullish" : "Bearish" },
                    { label: "vs SMA50", value: analysis.quote && analysis.indicators.sma50 < analysis.quote.price ? "Above ✓" : "Below ✗" },
                    { label: "vs SMA200", value: analysis.quote && analysis.indicators.sma200 < analysis.quote.price ? "Above ✓" : "Below ✗" },
                    { label: "Stochastic K", value: analysis.indicators.stochastic.toFixed(1) },
                  ].map(({ label, value }) => (
                    <div key={label} className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{label}</span>
                      <span className="font-mono font-medium">{value}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="rounded-lg border border-green-900/30 bg-green-900/10 p-4">
              <h3 className="font-semibold text-green-400 flex items-center gap-2 mb-3"><CheckCircle className="h-4 w-4" /> Bullish Factors</h3>
              <ul className="space-y-2">{analysis.bullishFactors.map((f, i) => <li key={i} className="flex items-start gap-2 text-sm"><span className="text-green-400 mt-0.5">▲</span><span>{f}</span></li>)}</ul>
            </div>
            <div className="rounded-lg border border-red-900/30 bg-red-900/10 p-4">
              <h3 className="font-semibold text-red-400 flex items-center gap-2 mb-3"><XCircle className="h-4 w-4" /> Bearish Factors</h3>
              <ul className="space-y-2">{analysis.bearishFactors.map((f, i) => <li key={i} className="flex items-start gap-2 text-sm"><span className="text-red-400 mt-0.5">▼</span><span>{f}</span></li>)}</ul>
            </div>
            <div className="rounded-lg border border-yellow-900/30 bg-yellow-900/10 p-4">
              <h3 className="font-semibold text-yellow-400 flex items-center gap-2 mb-3"><AlertTriangle className="h-4 w-4" /> Key Risks</h3>
              <ul className="space-y-2">{analysis.risks.map((r, i) => <li key={i} className="flex items-start gap-2 text-sm"><span className="text-yellow-400 mt-0.5">!</span><span>{r}</span></li>)}</ul>
            </div>
          </div>

          <p className="text-xs text-muted-foreground text-center border-t border-border pt-4">
            Not financial advice. Always do your own research before investing.
          </p>
        </>
      )}
    </div>
  );
}

// ──────────────────────────── PORTFOLIO MANAGER ────────────────────────────
function PortfolioManagerTab({ portfolioId }: { portfolioId: string }) {
  const [data, setData] = useState<PortfolioManagerData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetch_ = async () => {
    setLoading(true); setError("");
    try {
      const url = portfolioId ? `/api/ai/portfolio-manager?portfolioId=${portfolioId}` : "/api/ai/portfolio-manager";
      const res = await fetch(url);
      if (!res.ok) { const d = await res.json(); throw new Error(d.error ?? "Failed"); }
      setData(await res.json());
    } catch (e: unknown) { setError(e instanceof Error ? e.message : "Failed"); }
    setLoading(false);
  };
  useEffect(() => { fetch_(); }, [portfolioId]);

  const actionColor = (a: string) => ({
    BUY_MORE: "text-green-400 bg-green-400/10 border-green-400/30",
    ACCUMULATE: "text-emerald-400 bg-emerald-400/10 border-emerald-400/30",
    HOLD: "text-yellow-400 bg-yellow-400/10 border-yellow-400/30",
    REDUCE: "text-orange-400 bg-orange-400/10 border-orange-400/30",
    EXIT: "text-red-400 bg-red-400/10 border-red-400/30",
  }[a] ?? "text-muted-foreground border-border bg-secondary/50");

  const riskColor = (r: string) => r === "HIGH" ? "text-red-400" : r === "MEDIUM" ? "text-yellow-400" : "text-green-400";

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2"><Briefcase className="h-5 w-5 text-primary" /> AI Portfolio Manager</h2>
          <p className="text-xs text-muted-foreground">Strategic rebalancing view — 3 to 6 month horizon · Not the same as today&apos;s tactical decisions</p>
        </div>
        <Button variant="outline" size="sm" onClick={fetch_} disabled={loading}>
          <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? "animate-spin" : ""}`} /> Refresh
        </Button>
      </div>

      {error && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-destructive text-sm">{error}</div>}
      {loading && (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Briefcase className="h-12 w-12 text-primary animate-pulse" />
          <p className="text-muted-foreground">AI analyzing your complete portfolio…</p>
        </div>
      )}

      {data && !loading && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Health */}
            <div className="rounded-lg border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground mb-2">Portfolio Health</p>
              <div className="flex items-center gap-3">
                <div className="relative h-16 w-16">
                  <svg className="h-16 w-16 -rotate-90" viewBox="0 0 64 64">
                    <circle cx="32" cy="32" r="26" fill="none" stroke="hsl(var(--border))" strokeWidth="6" />
                    <circle cx="32" cy="32" r="26" fill="none"
                      stroke={data.overallHealth.score >= 70 ? "#22c55e" : data.overallHealth.score >= 45 ? "#eab308" : "#ef4444"}
                      strokeWidth="6" strokeDasharray={`${(data.overallHealth.score / 100) * 163.4} 163.4`} strokeLinecap="round" />
                  </svg>
                  <span className="absolute inset-0 flex items-center justify-center text-sm font-bold">{data.overallHealth.score}</span>
                </div>
                <div>
                  <p className="text-xl font-bold">{data.overallHealth.status}</p>
                  <p className="text-xs text-muted-foreground">Status</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{data.overallHealth.summary}</p>
            </div>
            {/* Risk */}
            <div className="rounded-lg border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground mb-2">Risk Profile</p>
              <p className={`text-2xl font-bold ${riskColor(data.riskAnalysis.overallRisk)}`}>{data.riskAnalysis.overallRisk} RISK</p>
              <div className="mt-2 space-y-1 text-xs">
                <div className="flex justify-between"><span className="text-muted-foreground">Volatility</span><span>{data.riskAnalysis.volatilityProfile}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Diversification</span><span>{data.riskAnalysis.diversificationScore.toFixed(1)}/10</span></div>
              </div>
              <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{data.riskAnalysis.concentrationRisk}</p>
            </div>
            {/* Cash */}
            <div className="rounded-lg border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground mb-2">Cash Deployment</p>
              <p className="text-sm font-medium leading-relaxed">{data.cashDeployment.recommendation}</p>
              <p className="text-xs text-muted-foreground mt-1">{data.cashDeployment.suggestedAllocation}</p>
              <p className="text-xs text-muted-foreground mt-1"><span className="font-medium">Timing:</span> {data.cashDeployment.timing}</p>
            </div>
          </div>

          {/* Holding Recommendations Table */}
          <div className="rounded-lg border border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border">
              <h3 className="font-semibold flex items-center gap-2"><Target className="h-4 w-4 text-primary" /> Holding Recommendations</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-secondary/50">
                    {["Symbol","Action","Current %","Target %","Priority","Reason"].map(h => (
                      <th key={h} className="px-4 py-2.5 text-left text-xs font-medium text-muted-foreground whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.holdingRecommendations.map((r) => (
                    <tr key={r.symbol} className="border-b border-border/50 hover:bg-secondary/30">
                      <td className="px-4 py-2.5 font-mono font-bold text-primary">{r.symbol}</td>
                      <td className="px-4 py-2.5">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded border ${actionColor(r.action)}`}>{r.action.replace("_", " ")}</span>
                      </td>
                      <td className="px-4 py-2.5 font-mono">{r.currentWeight.toFixed(1)}%</td>
                      <td className="px-4 py-2.5 font-mono">{r.targetWeight.toFixed(1)}%</td>
                      <td className="px-4 py-2.5">
                        <Badge variant="outline" className={`text-xs ${r.priority === "HIGH" || r.priority === "URGENT" ? "border-red-500/50 text-red-400" : r.priority === "MEDIUM" ? "border-yellow-500/50 text-yellow-400" : "border-border text-muted-foreground"}`}>{r.priority}</Badge>
                      </td>
                      <td className="px-4 py-2.5 text-xs text-muted-foreground max-w-xs">{r.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Sector Exposure */}
          <div className="rounded-lg border border-border bg-card p-4">
            <h3 className="font-semibold mb-4 flex items-center gap-2"><BarChart2 className="h-4 w-4 text-primary" /> Sector Exposure</h3>
            <div className="space-y-3">
              {data.sectorExposure.map((s) => (
                <div key={s.sector}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium">{s.sector}</span>
                    <div className="flex items-center gap-3">
                      <span className={`text-xs font-bold ${s.action === "OVERWEIGHT" ? "text-red-400" : s.action === "UNDERWEIGHT" ? "text-yellow-400" : "text-green-400"}`}>{s.action}</span>
                      <span className="text-xs font-mono">{s.currentPct.toFixed(1)}%</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${Math.min(100, s.currentPct * 3)}%`, backgroundColor: s.action === "OVERWEIGHT" ? "#ef4444" : s.action === "UNDERWEIGHT" ? "#eab308" : "#22c55e" }} />
                    </div>
                    <span className="text-xs text-muted-foreground shrink-0 w-16 text-right">tgt {s.targetPct.toFixed(0)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Rebalancing Plan + Outlook */}
          <div className="rounded-lg border border-border bg-card p-4">
            <h3 className="font-semibold mb-3 flex items-center gap-2"><ArrowRight className="h-4 w-4 text-primary" /> Rebalancing Plan</h3>
            <div className="space-y-3">
              {data.rebalancingPlan.map((p) => (
                <div key={p.step} className="flex items-start gap-3">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center">{p.step}</div>
                  <div>
                    <p className="text-sm">{p.action}</p>
                    <p className="text-xs text-muted-foreground">{p.impact}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-3 border-t border-border">
              <p className="text-xs font-medium text-muted-foreground mb-1">6-Month Outlook</p>
              <p className="text-sm text-muted-foreground leading-relaxed">{data.sixMonthOutlook}</p>
            </div>
          </div>

          <p className="text-xs text-muted-foreground text-center">{data.disclaimer}</p>
        </>
      )}
    </div>
  );
}

// ──────────────────────────── DECISION DASHBOARD ────────────────────────────
function DecisionTab({ portfolioId }: { portfolioId: string }) {
  const [data, setData] = useState<DecisionData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetch_ = async () => {
    setLoading(true); setError("");
    try {
      const url = portfolioId ? `/api/ai/decision?portfolioId=${portfolioId}` : "/api/ai/decision";
      const res = await fetch(url);
      if (!res.ok) { const d = await res.json(); throw new Error(d.error ?? "Failed"); }
      setData(await res.json());
    } catch (e: unknown) { setError(e instanceof Error ? e.message : "Failed"); }
    setLoading(false);
  };
  useEffect(() => { fetch_(); }, [portfolioId]);

  const actionColor = (a: string) => {
    if (["BUY", "ACCUMULATE"].includes(a)) return "text-green-400 bg-green-400/10 border-green-400/30";
    if (["SELL", "REDUCE"].includes(a)) return "text-red-400 bg-red-400/10 border-red-400/30";
    if (a === "WATCH") return "text-blue-400 bg-blue-400/10 border-blue-400/30";
    return "text-yellow-400 bg-yellow-400/10 border-yellow-400/30";
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2"><Crosshair className="h-5 w-5 text-primary" /> AI Decision Dashboard</h2>
          <p className="text-xs text-muted-foreground">Today&apos;s tactical actions based on technicals · May differ from Portfolio Manager&apos;s long-term rebalancing plan</p>
        </div>
        <Button variant="outline" size="sm" onClick={fetch_} disabled={loading}>
          <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? "animate-spin" : ""}`} /> Refresh
        </Button>
      </div>

      {error && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-destructive text-sm">{error}</div>}
      {loading && (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Crosshair className="h-12 w-12 text-primary animate-pulse" />
          <p className="text-muted-foreground">Building today&apos;s decision plan…</p>
        </div>
      )}

      {data && !loading && (
        <>
          {/* Market Context */}
          <div className="rounded-lg border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground mb-1">Market Context</p>
            <p className="text-sm leading-relaxed">{data.marketContext}</p>
          </div>

          {/* Today's Decisions */}
          <div className="rounded-lg border border-border bg-card p-4">
            <h3 className="font-semibold mb-3 flex items-center gap-2"><Zap className="h-4 w-4 text-primary" /> Today&apos;s Decisions</h3>
            <div className="grid gap-2">
              {data.todayDecisions.map((d) => (
                <div key={d.symbol} className={`flex items-start gap-3 rounded-lg border px-3 py-2.5 ${actionColor(d.action)}`}>
                  <span className={`shrink-0 text-xs font-bold px-2 py-0.5 rounded border font-mono ${actionColor(d.action)}`}>{d.action}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold">{d.symbol}</span>
                      <span className="text-xs opacity-70">{d.priceLevel}</span>
                    </div>
                    <p className="text-xs mt-0.5 opacity-80 leading-relaxed">{d.reason}</p>
                  </div>
                  <Badge variant="outline" className={`shrink-0 text-xs ${d.urgency === "URGENT" || d.urgency === "HIGH" ? "border-red-500 text-red-400" : d.urgency === "MEDIUM" ? "border-yellow-500 text-yellow-400" : "border-border"}`}>
                    {d.urgency}
                  </Badge>
                </div>
              ))}
            </div>
          </div>

          {/* High Conviction + Alerts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2 text-sm"><Star className="h-4 w-4 text-yellow-400" /><span className="text-yellow-400">High Conviction</span></h3>
              <div className="space-y-3">
                {data.highConviction.map((h) => (
                  <div key={h.symbol} className={`rounded-lg p-3 border ${h.direction === "LONG" ? "border-green-900/40 bg-green-900/10" : "border-red-900/40 bg-red-900/10"}`}>
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold">{h.symbol}</span>
                      <Badge variant="outline" className={h.direction === "LONG" ? "text-green-400 border-green-500/40" : "text-red-400 border-red-500/40"}>{h.direction}</Badge>
                    </div>
                    <p className="text-xs mt-1 leading-relaxed">{h.why}</p>
                    <div className="flex gap-3 mt-1.5 text-xs text-muted-foreground">
                      <span>Confidence: <span className="font-mono font-bold">{h.confidence}%</span></span>
                      <span>· {h.timeframe}</span>
                    </div>
                    <p className="text-xs text-primary mt-1">Catalyst: {h.catalyst}</p>
                  </div>
                ))}
                {data.highConviction.length === 0 && <p className="text-xs text-muted-foreground">No high-conviction trades today. Maintain existing positions.</p>}
              </div>
            </div>

            <div className="space-y-4">
              {data.alerts.nearStopLoss.length > 0 && (
                <div className="rounded-lg border border-red-900/40 bg-red-900/10 p-4">
                  <h3 className="font-semibold mb-3 flex items-center gap-2 text-red-400 text-sm"><AlertTriangle className="h-4 w-4" /> Near Stop Loss</h3>
                  <div className="space-y-2">
                    {data.alerts.nearStopLoss.map((a) => (
                      <div key={a.symbol} className="border-b border-red-900/20 pb-2 last:border-0 last:pb-0">
                        <div className="flex justify-between">
                          <span className="font-mono font-bold text-red-400">{a.symbol}</span>
                          <span className="text-xs font-mono text-red-400">{a.distancePct.toFixed(1)}% above SL</span>
                        </div>
                        <p className="text-xs text-muted-foreground">CMP: ₹{a.currentPrice.toFixed(0)} | SL: ₹{a.stopLoss.toFixed(0)}</p>
                        <p className="text-xs mt-0.5 leading-relaxed">{a.action}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {data.alerts.nearTarget.length > 0 && (
                <div className="rounded-lg border border-green-900/40 bg-green-900/10 p-4">
                  <h3 className="font-semibold mb-3 flex items-center gap-2 text-green-400 text-sm"><Target className="h-4 w-4" /> Near Target</h3>
                  <div className="space-y-2">
                    {data.alerts.nearTarget.map((a) => (
                      <div key={a.symbol} className="border-b border-green-900/20 pb-2 last:border-0 last:pb-0">
                        <div className="flex justify-between">
                          <span className="font-mono font-bold text-green-400">{a.symbol}</span>
                          <span className="text-xs font-mono text-green-400">{a.distancePct.toFixed(1)}% to target</span>
                        </div>
                        <p className="text-xs text-muted-foreground">CMP: ₹{a.currentPrice.toFixed(0)} | Target: ₹{a.target.toFixed(0)}</p>
                        <p className="text-xs mt-0.5 leading-relaxed">{a.action}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {data.alerts.nearStopLoss.length === 0 && data.alerts.nearTarget.length === 0 && (
                <div className="rounded-lg border border-border bg-card p-4">
                  <p className="text-xs text-green-400 font-medium">✓ No critical alerts</p>
                  <p className="text-xs text-muted-foreground mt-1">All positions are within normal ranges — no stop-loss or target triggers today.</p>
                </div>
              )}
            </div>
          </div>

          {/* Strengths + Weaknesses */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-lg border border-green-900/30 bg-green-900/10 p-4">
              <h3 className="font-semibold text-green-400 flex items-center gap-2 mb-3 text-sm"><CheckCircle className="h-4 w-4" /> Portfolio Strengths</h3>
              <ul className="space-y-1.5">{data.portfolioStrengths.map((s, i) => <li key={i} className="flex items-start gap-2 text-sm"><span className="text-green-400 mt-0.5 shrink-0">▲</span>{s}</li>)}</ul>
            </div>
            <div className="rounded-lg border border-red-900/30 bg-red-900/10 p-4">
              <h3 className="font-semibold text-red-400 flex items-center gap-2 mb-3 text-sm"><XCircle className="h-4 w-4" /> Portfolio Weaknesses</h3>
              <ul className="space-y-1.5">{data.portfolioWeaknesses.map((w, i) => <li key={i} className="flex items-start gap-2 text-sm"><span className="text-red-400 mt-0.5 shrink-0">▼</span>{w}</li>)}</ul>
            </div>
          </div>

          {/* Weekly Plan */}
          <div className="rounded-lg border border-border bg-card p-4">
            <h3 className="font-semibold mb-2 text-sm flex items-center gap-2"><Calendar className="h-4 w-4 text-primary" /> Weekly Action Plan</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{data.weeklyPlan}</p>
          </div>

          <p className="text-xs text-muted-foreground text-center">{data.disclaimer}</p>
        </>
      )}
    </div>
  );
}

// ──────────────────────────── FORECAST ────────────────────────────
function ForecastTab() {
  const [symbol, setSymbol] = useState("RELIANCE");
  const [inputVal, setInputVal] = useState("RELIANCE");
  const [exchange, setExchange] = useState("NSE");
  const [data, setData] = useState<ForecastData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchForecast = async (sym: string, ex: string) => {
    setLoading(true); setError("");
    try {
      const res = await fetch(`/api/ai/forecast?symbol=${sym}&exchange=${ex}`);
      if (!res.ok) throw new Error("Forecast failed");
      setData(await res.json());
    } catch { setError(`Could not forecast "${sym}". Check symbol and try again.`); }
    setLoading(false);
  };

  useEffect(() => { fetchForecast(symbol, exchange); }, []);

  const handleSearch = () => {
    const s = resolveSearchSymbol(inputVal.trim());
    if (s) { setSymbol(s); setInputVal(s); fetchForecast(s, exchange); }
  };

  const biasColor = (b: string) => b.includes("BULLISH") ? "text-green-400" : b.includes("BEARISH") ? "text-red-400" : "text-yellow-400";

  const TF_LABELS: Record<string, string> = { "1M": "1 Month", "3M": "3 Months", "6M": "6 Months", "1Y": "1 Year" };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold flex items-center gap-2"><TrendingUp className="h-5 w-5 text-primary" /> Target Forecast Engine</h2>
        {data?.generatedAt && <p className="text-xs text-muted-foreground">{data.generatedAt}</p>}
      </div>

      <div className="flex gap-2 max-w-sm items-center">
        <Input placeholder="NSE symbol (RELIANCE, TCS…)" value={inputVal} onChange={(e) => setInputVal(e.target.value.toUpperCase())} onKeyDown={(e) => e.key === "Enter" && handleSearch()} className="font-mono" />
        <select value={exchange} onChange={(e) => setExchange(e.target.value)} className="h-9 rounded-md border border-input bg-background px-3 text-sm">
          <option value="NSE">NSE</option>
          <option value="BSE">BSE</option>
        </select>
        <Button onClick={handleSearch} disabled={loading}><Search className="h-4 w-4" /></Button>
      </div>

      {error && <p className="text-destructive text-sm">{error}</p>}
      {loading && (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <TrendingUp className="h-12 w-12 text-primary animate-pulse" />
          <p className="text-muted-foreground">AI computing multi-timeframe forecasts…</p>
        </div>
      )}

      {data && !loading && (
        <>
          {/* Header */}
          <div className="flex flex-wrap items-center gap-4 rounded-lg border border-border bg-card p-4">
            <div>
              <h2 className="text-xl font-bold font-mono">{data.symbol}</h2>
              <p className="text-sm text-muted-foreground">{data.name}</p>
            </div>
            <div>
              <p className="text-xl font-mono font-bold">₹{data.currentPrice.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">Current Price</p>
            </div>
            <div className="ml-auto">
              <p className={`text-xl font-bold ${biasColor(data.technicalBias)}`}>{data.technicalBias.replace(/_/g, " ")}</p>
              <p className="text-xs text-muted-foreground">Technical Bias</p>
            </div>
          </div>

          {/* Timeframe Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            {data.forecasts.map((f) => (
              <div key={f.timeframe} className="rounded-lg border border-border bg-card overflow-hidden flex flex-col">
                <div className="bg-secondary/60 px-4 py-2.5 border-b border-border">
                  <p className="font-bold text-primary">{TF_LABELS[f.timeframe] ?? f.timeframe}</p>
                  <p className="text-xs text-muted-foreground truncate">{f.catalyst}</p>
                </div>
                <div className="p-3 space-y-2.5 flex-1">
                  {/* Bull */}
                  <div className="rounded-md border border-green-900/40 bg-green-900/10 p-2.5">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="text-xs font-bold text-green-400">BULL</span>
                      <span className="text-xs text-green-400">{f.bull.probability}%</span>
                    </div>
                    <p className="font-mono font-bold text-green-400 text-sm">₹{f.bull.price.toFixed(0)}</p>
                    <p className="text-xs text-green-400">+{f.bull.changePercent.toFixed(1)}%</p>
                    <div className="mt-1.5 h-1 bg-green-900/30 rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: `${f.bull.probability}%` }} />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1.5 leading-tight">{f.bull.rationale}</p>
                  </div>
                  {/* Base */}
                  <div className="rounded-md border border-yellow-900/40 bg-yellow-900/10 p-2.5">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="text-xs font-bold text-yellow-400">BASE</span>
                      <span className="text-xs text-yellow-400">{f.base.probability}%</span>
                    </div>
                    <p className="font-mono font-bold text-yellow-400 text-sm">₹{f.base.price.toFixed(0)}</p>
                    <p className="text-xs text-yellow-400">{f.base.changePercent >= 0 ? "+" : ""}{f.base.changePercent.toFixed(1)}%</p>
                    <div className="mt-1.5 h-1 bg-yellow-900/30 rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 rounded-full" style={{ width: `${f.base.probability}%` }} />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1.5 leading-tight">{f.base.rationale}</p>
                  </div>
                  {/* Bear */}
                  <div className="rounded-md border border-red-900/40 bg-red-900/10 p-2.5">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="text-xs font-bold text-red-400">BEAR</span>
                      <span className="text-xs text-red-400">{f.bear.probability}%</span>
                    </div>
                    <p className="font-mono font-bold text-red-400 text-sm">₹{f.bear.price.toFixed(0)}</p>
                    <p className="text-xs text-red-400">{f.bear.changePercent.toFixed(1)}%</p>
                    <div className="mt-1.5 h-1 bg-red-900/30 rounded-full overflow-hidden">
                      <div className="h-full bg-red-500 rounded-full" style={{ width: `${f.bear.probability}%` }} />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1.5 leading-tight">{f.bear.rationale}</p>
                  </div>
                  <p className="text-xs text-muted-foreground"><span className="font-medium">Key Level:</span> {f.keyLevel}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Technical Summary + Risks */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="font-semibold mb-3 text-sm">Technical Summary</h3>
              <div className="space-y-2">
                {[
                  { label: "RSI(14)", value: `${data.technicalSummary.rsi.toFixed(1)}${data.technicalSummary.rsi > 70 ? " — Overbought" : data.technicalSummary.rsi < 30 ? " — Oversold" : " — Neutral"}` },
                  { label: "Trend", value: data.technicalSummary.trend },
                  { label: "MACD", value: data.technicalSummary.macdSignal },
                  { label: "Support", value: `₹${data.technicalSummary.support.toFixed(0)}` },
                  { label: "Resistance", value: `₹${data.technicalSummary.resistance.toFixed(0)}` },
                  { label: "Stochastic", value: data.technicalSummary.stochastic.toFixed(1) },
                  { label: "vs SMA50", value: data.technicalSummary.aboveSMA50 ? "Above ✓" : "Below ✗" },
                  { label: "vs SMA200", value: data.technicalSummary.aboveSMA200 ? "Above ✓" : "Below ✗" },
                ].map(({ label, value }) => (
                  <div key={label} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{label}</span>
                    <span className="font-mono font-medium text-right max-w-[60%]">{value}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-lg border border-yellow-900/30 bg-yellow-900/10 p-4">
              <h3 className="font-semibold text-yellow-400 flex items-center gap-2 mb-3 text-sm"><AlertTriangle className="h-4 w-4" /> Key Risks</h3>
              <ul className="space-y-2">
                {data.keyRisks.map((r, i) => <li key={i} className="flex items-start gap-2 text-sm"><span className="text-yellow-400 mt-0.5 shrink-0">!</span><span>{r}</span></li>)}
              </ul>
            </div>
          </div>

          <p className="text-xs text-muted-foreground text-center">{data.disclaimer}</p>
        </>
      )}
    </div>
  );
}

// ──────────────────────────── MAIN ────────────────────────────
type Tab = "brief" | "opportunities" | "portfolio-manager" | "decision" | "forecast" | "chat" | "analysis";

function AIContent() {
  const [tab, setTab] = useState<Tab>("brief");
  const { activePortfolioId } = usePortfolio();
  const pid = activePortfolioId ?? "";

  const TABS = [
    { id: "brief" as Tab,             label: "Daily Brief",       icon: Calendar },
    { id: "opportunities" as Tab,     label: "Opportunities",     icon: Sparkles },
    { id: "portfolio-manager" as Tab, label: "Portfolio Manager", icon: Briefcase },
    { id: "decision" as Tab,          label: "Decisions",         icon: Crosshair },
    { id: "forecast" as Tab,          label: "Forecast",          icon: TrendingUp },
    { id: "chat" as Tab,              label: "AI Chat",           icon: MessageSquare },
    { id: "analysis" as Tab,          label: "Stock Analysis",    icon: Brain },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Brain className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">AI Investment Advisor</h1>
          <p className="text-xs text-muted-foreground">Powered by Google Gemini · Indian Market Expert</p>
        </div>
      </div>

      <div className="flex gap-1 border-b border-border overflow-x-auto pb-px">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${tab === id ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          >
            <Icon className="h-4 w-4" /> {label}
          </button>
        ))}
      </div>

      {tab === "brief"             && <BriefTab             portfolioId={pid} />}
      {tab === "opportunities"     && <OpportunitiesTab     portfolioId={pid} />}
      {tab === "portfolio-manager" && <PortfolioManagerTab  portfolioId={pid} />}
      {tab === "decision"          && <DecisionTab          portfolioId={pid} />}
      {tab === "forecast"          && <ForecastTab />}
      {tab === "chat"              && <ChatTab />}
      {tab === "analysis"          && <AnalysisTab />}
    </div>
  );
}

export default function AIPage() {
  return (
    <Suspense fallback={<div className="p-6 text-muted-foreground">Loading…</div>}>
      <AIContent />
    </Suspense>
  );
}
