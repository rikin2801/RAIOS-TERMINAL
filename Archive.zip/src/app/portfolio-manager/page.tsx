"use client";

import { useState, useCallback, useEffect } from "react";
import { usePortfolio } from "@/contexts/portfolio-context";
import { formatCurrency, formatPercent } from "@/lib/utils";
import {
  Target, RefreshCw, TrendingUp, TrendingDown, AlertTriangle,
  CheckCircle, Shield, Zap, BarChart2, ArrowUpRight, ArrowDownRight,
  Minus, Brain, Calendar, ChevronDown, ChevronUp, Clock,
} from "lucide-react";
import type { PortfolioManagerData } from "@/app/api/ai/portfolio-manager/route";
import type { DailyBrief } from "@/app/api/ai/brief/route";

const ACTION_STYLES: Record<string, string> = {
  BUY_MORE:   "text-green-400 bg-green-400/10 border border-green-400/20",
  ACCUMULATE: "text-emerald-400 bg-emerald-400/10 border border-emerald-400/20",
  HOLD:       "text-yellow-400 bg-yellow-400/10 border border-yellow-400/20",
  REDUCE:     "text-orange-400 bg-orange-400/10 border border-orange-400/20",
  EXIT:       "text-red-400 bg-red-400/10 border border-red-400/20",
};

const ACTION_ICONS: Record<string, typeof ArrowUpRight> = {
  BUY_MORE:   ArrowUpRight,
  ACCUMULATE: ArrowUpRight,
  HOLD:       Minus,
  REDUCE:     ArrowDownRight,
  EXIT:       ArrowDownRight,
};

const BRIEF_ACTION_STYLES: Record<string, string> = {
  BUY:        "text-green-400",
  ACCUMULATE: "text-emerald-400",
  HOLD:       "text-yellow-400",
  REDUCE:     "text-orange-400",
  SELL:       "text-red-400",
  WATCH:      "text-blue-400",
};

const URGENCY_BADGES: Record<string, string> = {
  HIGH:   "bg-red-400/15 text-red-400 border-red-400/30",
  MEDIUM: "bg-yellow-400/15 text-yellow-400 border-yellow-400/30",
  LOW:    "bg-muted/40 text-muted-foreground border-border",
  URGENT: "bg-red-500/20 text-red-300 border-red-500/40",
};

const HEALTH_COLOR = (score: number) =>
  score >= 80 ? "text-green-400" : score >= 60 ? "text-yellow-400" : score >= 40 ? "text-orange-400" : "text-red-400";

export default function PortfolioManagerPage() {
  const { activePortfolioId, activePortfolio } = usePortfolio();
  const [pmData, setPmData] = useState<PortfolioManagerData | null>(null);
  const [brief, setBrief] = useState<DailyBrief | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [expandedRecs, setExpandedRecs] = useState<Record<string, boolean>>({});
  const [activeTab, setActiveTab] = useState<"brief" | "portfolio" | "actions" | "risk" | "rebalance">("brief");

  const refresh = useCallback(async () => {
    if (!activePortfolioId) return;
    setLoading(true);
    setError(null);
    setAiError(null);
    try {
      const [pmRes, briefRes] = await Promise.all([
        fetch(`/api/ai/portfolio-manager?portfolioId=${activePortfolioId}`),
        fetch(`/api/ai/brief?portfolioId=${activePortfolioId}`),
      ]);
      if (pmRes.ok) {
        const pmJson = await pmRes.json();
        setPmData(pmJson);
        if (pmJson.aiError) setAiError(pmJson.aiError);
      } else { const e = await pmRes.json(); setError(e.error ?? "Failed to load portfolio analysis"); }
      if (briefRes.ok) {
        const briefJson = await briefRes.json();
        setBrief(briefJson);
        if (briefJson.aiError) setAiError((prev) => prev ?? briefJson.aiError);
      }
    } catch (e) {
      setError("Connection error. Make sure the dev server is running.");
    } finally {
      setLoading(false);
    }
  }, [activePortfolioId]);

  useEffect(() => { refresh(); }, [refresh]);

  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
  });

  if (error && !pmData) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-card border border-border rounded-lg p-8 text-center">
          <Brain className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-lg font-semibold mb-2">Portfolio Analysis Unavailable</h2>
          <p className="text-sm text-muted-foreground mb-4">{error}</p>
          <button onClick={refresh} className="bg-primary text-primary-foreground px-4 py-2 rounded text-sm font-medium hover:bg-primary/90">
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-6 py-4 border-b border-border bg-card/50 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-bold">AI Portfolio Manager</h1>
            {pmData && (
              <span className={`text-xs font-semibold px-2 py-0.5 rounded ${HEALTH_COLOR(pmData.overallHealth.score)} bg-current/10`}>
                {pmData.overallHealth.status}
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">{activePortfolio?.name} · {today}</p>
        </div>
        <button
          onClick={refresh}
          disabled={loading}
          className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground border border-border rounded-md px-3 py-1.5 transition-colors hover:bg-accent"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
          {loading ? "Refreshing…" : "Refresh All"}
        </button>
      </div>

      {/* AI Error Banner */}
      {aiError && (
        <div className="px-6 py-2.5 bg-yellow-500/10 border-b border-yellow-500/20 flex items-center gap-2 text-xs text-yellow-400">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          <span>{aiError}</span>
        </div>
      )}

      {/* Portfolio Health Score Bar */}
      {pmData && (
        <div className="px-6 py-3 border-b border-border bg-card/30 flex items-center gap-6 overflow-x-auto">
          <div className="flex items-center gap-3 shrink-0">
            <div className={`text-3xl font-bold ${HEALTH_COLOR(pmData.overallHealth.score)}`}>
              {pmData.overallHealth.score}
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground">Portfolio Health</p>
              <p className="text-xs text-muted-foreground">out of 100</p>
            </div>
          </div>
          <div className="h-2 flex-1 min-w-[120px] bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${pmData.overallHealth.score >= 80 ? "bg-green-400" : pmData.overallHealth.score >= 60 ? "bg-yellow-400" : "bg-red-400"}`}
              style={{ width: `${pmData.overallHealth.score}%` }}
            />
          </div>
          <div className="flex items-center gap-4 shrink-0 text-xs text-muted-foreground">
            <div className="text-center">
              <p className="font-semibold text-foreground">{pmData.riskAnalysis.diversificationScore.toFixed(1)}/10</p>
              <p>Diversity</p>
            </div>
            <div className="text-center">
              <p className={`font-semibold ${pmData.riskAnalysis.overallRisk === "HIGH" ? "text-red-400" : pmData.riskAnalysis.overallRisk === "MEDIUM" ? "text-yellow-400" : "text-green-400"}`}>
                {pmData.riskAnalysis.overallRisk}
              </p>
              <p>Risk</p>
            </div>
            <div className="text-center">
              <p className={`font-semibold ${pmData.riskAnalysis.volatilityProfile === "CONSERVATIVE" ? "text-green-400" : pmData.riskAnalysis.volatilityProfile === "AGGRESSIVE" ? "text-red-400" : "text-yellow-400"}`}>
                {pmData.riskAnalysis.volatilityProfile}
              </p>
              <p>Profile</p>
            </div>
          </div>
        </div>
      )}

      {/* Tab bar */}
      <div className="px-6 pt-3 border-b border-border flex gap-0">
        {(["brief", "portfolio", "actions", "risk", "rebalance"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setActiveTab(t)}
            className={`px-4 py-2 text-xs font-semibold capitalize border-b-2 transition-colors ${
              activeTab === t ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t === "brief" ? "Daily Brief" : t === "portfolio" ? "Holdings" : t === "actions" ? "Today's Actions" : t === "risk" ? "Risk" : "Rebalance"}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-auto p-6">
        {loading && !pmData && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Brain className="h-10 w-10 text-primary animate-pulse" />
            <p className="text-sm text-muted-foreground">AI is analyzing your portfolio…</p>
            <p className="text-xs text-muted-foreground">Fetching live prices and generating recommendations</p>
          </div>
        )}

        {/* DAILY BRIEF TAB */}
        {activeTab === "brief" && brief && (
          <div className="space-y-4 max-w-4xl">
            {/* Good morning card */}
            <div className="bg-card border border-border rounded-lg p-5">
              <div className="flex items-start gap-4">
                <div className={`flex-1`}>
                  <h2 className="text-base font-bold">Good Morning, {activePortfolio?.name?.split(" ")[0] ?? "Investor"}.</h2>
                  <p className="text-xs text-muted-foreground mt-0.5">{brief.date}</p>
                  <p className="text-sm mt-3 leading-relaxed">{brief.portfolioHealth.summary}</p>
                </div>
                <div className="text-center shrink-0">
                  <p className={`text-4xl font-bold ${HEALTH_COLOR(brief.portfolioHealth.score)}`}>{brief.portfolioHealth.grade}</p>
                  <p className="text-xs text-muted-foreground mt-1">Portfolio Grade</p>
                </div>
              </div>
            </div>

            {/* Market Sentiment */}
            <div className="grid grid-cols-3 gap-3">
              <div className={`bg-card border rounded-lg p-3 ${brief.marketSentiment.overall === "BULLISH" ? "border-green-400/30" : brief.marketSentiment.overall === "BEARISH" ? "border-red-400/30" : "border-border"}`}>
                <p className="text-xs text-muted-foreground">Market Sentiment</p>
                <p className={`text-sm font-bold mt-1 ${brief.marketSentiment.overall === "BULLISH" ? "text-green-400" : brief.marketSentiment.overall === "BEARISH" ? "text-red-400" : "text-yellow-400"}`}>
                  {brief.marketSentiment.overall}
                </p>
              </div>
              <div className="bg-card border border-border rounded-lg p-3 col-span-2">
                <p className="text-xs text-muted-foreground">India Context</p>
                <p className="text-xs mt-1 leading-relaxed">{brief.marketSentiment.india}</p>
              </div>
            </div>

            {/* Today's Actions */}
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-border">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-primary" />
                  Today's Action Plan
                </h3>
              </div>
              <div className="divide-y divide-border">
                {brief.todayActions.map((a, i) => (
                  <div key={i} className="flex items-start gap-3 px-4 py-3">
                    <span className={`text-xs font-bold px-2 py-0.5 rounded ${BRIEF_ACTION_STYLES[a.action]}`}>{a.action}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold">{a.symbol}</span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${URGENCY_BADGES[a.urgency]}`}>{a.urgency}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">{a.reason}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Opportunity + Risk */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-card border border-green-400/20 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="h-4 w-4 text-green-400" />
                  <p className="text-xs font-semibold text-green-400">TOP OPPORTUNITY</p>
                </div>
                <p className="text-sm font-bold">{brief.topOpportunity.symbol}</p>
                <p className="text-xs text-muted-foreground mt-1">{brief.topOpportunity.why}</p>
                <div className="mt-2 space-y-0.5">
                  <p className="text-xs"><span className="text-muted-foreground">Entry:</span> {brief.topOpportunity.entryRange}</p>
                  <p className="text-xs"><span className="text-muted-foreground">Target:</span> {brief.topOpportunity.target}</p>
                </div>
              </div>
              <div className="bg-card border border-red-400/20 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="h-4 w-4 text-red-400" />
                  <p className="text-xs font-semibold text-red-400">HIGHEST RISK</p>
                </div>
                <p className="text-sm font-bold">{brief.highestRisk.symbol}</p>
                <p className="text-xs text-muted-foreground mt-1">{brief.highestRisk.risk}</p>
                <p className="text-xs mt-2 text-orange-400">{brief.highestRisk.action}</p>
              </div>
            </div>

            {/* Insights Row */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs font-semibold text-muted-foreground mb-1">SECTOR ROTATION</p>
                <p className="text-xs leading-relaxed">{brief.sectorRotation}</p>
              </div>
              <div className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs font-semibold text-muted-foreground mb-1">CASH DEPLOYMENT</p>
                <p className="text-xs leading-relaxed">{brief.cashDeployment}</p>
              </div>
            </div>

            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-xs font-semibold text-muted-foreground mb-1">KEY THEME THIS WEEK</p>
              <p className="text-sm font-medium">{brief.keyTheme}</p>
            </div>

            <p className="text-[10px] text-muted-foreground">{brief.disclaimer}</p>
          </div>
        )}

        {/* HOLDINGS TAB */}
        {activeTab === "portfolio" && pmData && (
          <div className="space-y-3 max-w-4xl">
            <p className="text-xs text-muted-foreground">{pmData.overallHealth.summary}</p>
            {pmData.holdingRecommendations.map((rec) => {
              const Icon = ACTION_ICONS[rec.action] ?? Minus;
              const expanded = expandedRecs[rec.symbol];
              return (
                <div key={rec.symbol} className="bg-card border border-border rounded-lg overflow-hidden">
                  <div
                    className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-accent/30 transition-colors"
                    onClick={() => setExpandedRecs((p) => ({ ...p, [rec.symbol]: !p[rec.symbol] }))}
                  >
                    <Icon className={`h-4 w-4 shrink-0 ${ACTION_STYLES[rec.action].split(" ")[0]}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold">{rec.symbol}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${ACTION_STYLES[rec.action]}`}>{rec.action.replace("_", " ")}</span>
                        {rec.priority !== "LOW" && (
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${URGENCY_BADGES[rec.priority]}`}>{rec.priority}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground shrink-0">
                      <span>{rec.currentWeight.toFixed(1)}% → <span className="text-foreground font-medium">{rec.targetWeight.toFixed(1)}%</span></span>
                      {expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                    </div>
                  </div>
                  {expanded && (
                    <div className="px-4 pb-4 pt-0 border-t border-border">
                      <p className="text-xs text-muted-foreground mt-3 leading-relaxed">{rec.reason}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ACTIONS TAB */}
        {activeTab === "actions" && brief && (
          <div className="space-y-4 max-w-4xl">
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-border">
                <h3 className="text-sm font-semibold">Today's Tactical Decisions</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Short-term technical signals · {brief.date}</p>
              </div>
              <div className="divide-y divide-border">
                {brief.todayActions.map((a, i) => (
                  <div key={i} className="px-4 py-4">
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`text-sm font-bold ${BRIEF_ACTION_STYLES[a.action]}`}>{a.action}</span>
                      <span className="text-sm font-semibold">{a.symbol}</span>
                      <span className={`ml-auto text-[10px] font-bold px-2 py-0.5 rounded border ${URGENCY_BADGES[a.urgency]}`}>{a.urgency}</span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{a.reason}</p>
                  </div>
                ))}
              </div>
            </div>

            {pmData && (
              <div className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs font-semibold text-muted-foreground mb-2">REBALANCING NOTE</p>
                <p className="text-xs leading-relaxed">{pmData.cashDeployment.recommendation}</p>
                <p className="text-xs text-muted-foreground mt-2">{pmData.cashDeployment.timing}</p>
              </div>
            )}
          </div>
        )}

        {/* RISK TAB */}
        {activeTab === "risk" && pmData && (
          <div className="space-y-4 max-w-4xl">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs font-semibold text-muted-foreground mb-1">CONCENTRATION RISK</p>
                <p className="text-xs leading-relaxed mt-2">{pmData.riskAnalysis.concentrationRisk}</p>
              </div>
              <div className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs font-semibold text-muted-foreground mb-1">SECTOR RISK</p>
                <p className="text-xs leading-relaxed mt-2">{pmData.riskAnalysis.sectorRisk}</p>
              </div>
            </div>

            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-border">
                <h3 className="text-sm font-semibold">Sector Exposure</h3>
              </div>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Sector</th>
                    <th>Current</th>
                    <th>Target</th>
                    <th>Status</th>
                    <th>Suggestion</th>
                  </tr>
                </thead>
                <tbody>
                  {pmData.sectorExposure.map((s) => (
                    <tr key={s.sector}>
                      <td className="font-medium">{s.sector}</td>
                      <td className="font-mono">{s.currentPct.toFixed(1)}%</td>
                      <td className="font-mono text-muted-foreground">{s.targetPct.toFixed(1)}%</td>
                      <td>
                        <span className={`text-xs font-semibold ${s.action === "OVERWEIGHT" ? "text-red-400" : s.action === "UNDERWEIGHT" ? "text-yellow-400" : "text-green-400"}`}>
                          {s.action}
                        </span>
                      </td>
                      <td className="text-xs text-muted-foreground">{s.suggestion}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* REBALANCE TAB */}
        {activeTab === "rebalance" && pmData && (
          <div className="space-y-4 max-w-4xl">
            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-xs font-semibold text-muted-foreground mb-2">6-MONTH OUTLOOK</p>
              <p className="text-sm leading-relaxed">{pmData.sixMonthOutlook}</p>
            </div>

            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-border">
                <h3 className="text-sm font-semibold">Step-by-Step Rebalancing Plan</h3>
              </div>
              <div className="divide-y divide-border">
                {pmData.rebalancingPlan.map((step) => (
                  <div key={step.step} className="flex gap-4 px-4 py-4">
                    <div className="h-6 w-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {step.step}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{step.action}</p>
                      <p className="text-xs text-muted-foreground mt-1">{step.impact}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-xs font-semibold text-muted-foreground mb-2">CASH DEPLOYMENT</p>
              <p className="text-sm">{pmData.cashDeployment.recommendation}</p>
              <p className="text-xs text-muted-foreground mt-2">{pmData.cashDeployment.suggestedAllocation}</p>
              <p className="text-xs text-muted-foreground mt-1">{pmData.cashDeployment.timing}</p>
            </div>

            <p className="text-[10px] text-muted-foreground">{pmData.disclaimer}</p>
          </div>
        )}
      </div>
    </div>
  );
}
